magisk="/data/adb/modules"
log="/data/adb/modules/Mathrix_QuickDisableMagisk/log.txt"
flag=0
count=0

log_print()
{
    local info=$1
    echo "$info" >> $log
    echo "时间：$(date "+%Y年%m月%d日%H时%M分%S秒")" >> $log
    echo "" >> $log
}

while [ $flag -eq 0 ]; do
	
    event=$(timeout 1 getevent -lc 1)
    
    if [ -z "$event" ]; then  
        continue
    fi
    
    if echo "$event" | grep -i "KEY_VOLUMEUP" | grep -iw "DOWN" > /dev/null; then
        log_print "音量加键按下"
        let count++
    fi
    
    if echo "$event" | grep -i "KEY_VOLUMEDOWN" | grep -iw "DOWN" > /dev/null; then
        log_print "音量减键按下"
        let count++
    fi
    
    if [ $count -eq 4 ]; then
        log_print "禁用模块并重启"
        for module in "$magisk"/* ; do
    	    if [ "$module" != "$magisk/Mathrix_QuickDisableMagisk" ]; then
    		    touch "$module/disable"
    		fi
        done
        sync
        sleep 1
    	reboot
    fi
    
    if [ "$(getprop sys.boot_completed)" = "1" ]; then
		log_print "开机完成"
	    flag=1
	fi
	
done