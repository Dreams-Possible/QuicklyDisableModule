echo "快速禁用模块"
echo "开机时按下4次任意音量键，关闭其余模块并重启"
echo "日志文件位于：/data/adb/modules/Mathrix_QuickDisableMagisk/log.txt"
echo "仅记录每次开机日志"